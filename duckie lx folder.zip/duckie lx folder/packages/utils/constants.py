ASSETS_DIR = "/code/catkin_ws/src/object-detection/assets"
